package com.cg.eventmanagement.beans;
public class Event {
	private String typeOfEvent,eventFromDate,eventToDate;
	private EventAddress eventaddress;
	private Catering catering;
	public Event(String typeOfEvent, String eventFromDate, String eventToDate, EventAddress eventaddress,
			Catering catering) {
		super();
		this.typeOfEvent = typeOfEvent;
		this.eventFromDate = eventFromDate;
		this.eventToDate = eventToDate;
		this.eventaddress = eventaddress;
		this.catering = catering;
	}
	public String getTypeOfEvent() {
		return typeOfEvent;
	}
	public void setTypeOfEvent(String typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}
	public String getEventFromDate() {
		return eventFromDate;
	}
	public void setEventFromDate(String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}
	public String getEventToDate() {
		return eventToDate;
	}
	public void setEventToDate(String eventToDate) {
		this.eventToDate = eventToDate;
	}
	public EventAddress getEventaddress() {
		return eventaddress;
	}
	public void setEventaddress(EventAddress eventaddress) {
		this.eventaddress = eventaddress;
	}
	public Catering getCatering() {
		return catering;
	}
	public void setCatering(Catering catering) {
		this.catering = catering;
	}
}
