package com.cg.eventmanagement.daoservices;

public class EventmanagementDAOServicesImpl {

}
