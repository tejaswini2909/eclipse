package com.cg.airreservation.beans;
public class Cancellation {
			private String lastDateForCancellation,cancellationPolicy;
			 private int percentageofCancellationperdayafterdeadline;
			public Transaction transactions;
			 public Cancellation() {}
			public Cancellation(String lastDateForCancellation, String cancellationPolicy,
					int percentageofCancellationperdayafterdeadline, Transaction transactions) {
				super();
				this.lastDateForCancellation = lastDateForCancellation;
				this.cancellationPolicy = cancellationPolicy;
				this.percentageofCancellationperdayafterdeadline = percentageofCancellationperdayafterdeadline;
				this.transactions = transactions;
			}
			public String getLastDateForCancellation() {
				return lastDateForCancellation;
			}
			public void setLastDateForCancellation(String lastDateForCancellation) {
				this.lastDateForCancellation = lastDateForCancellation;
			}
			public String getCancellationPolicy() {
				return cancellationPolicy;
			}
			public void setCancellationPolicy(String cancellationPolicy) {
				this.cancellationPolicy = cancellationPolicy;
			}
			public int getPercentageofCancellationperdayafterdeadline() {
				return percentageofCancellationperdayafterdeadline;
			}
			public void setPercentageofCancellationperdayafterdeadline(int percentageofCancellationperdayafterdeadline) {
				this.percentageofCancellationperdayafterdeadline = percentageofCancellationperdayafterdeadline;
			}
			public Transaction getTransactions() {
				return transactions;
			}
			public void setTransactions(Transaction transactions) {
				this.transactions = transactions;
			}
}