package com.cg.payroll.daoservices;

public class PayrollDAOServicesImpl {

}
