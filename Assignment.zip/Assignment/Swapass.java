public class Swapass{
	public static void main(String [] str){
		int a=2,b=3;
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a+" "+b);
	}
}