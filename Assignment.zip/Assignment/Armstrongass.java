public class Armstrongass{
	public static void main(String[] str){
		int n=331,i,arm=0,temp;
		temp=n;
		while(temp!=0){
		i=temp%10;
		arm=i*i*i+arm;
		temp=temp/10;
		}
		while(temp!=0){
		i=temp%10;
		arm=i*i*i+arm;
		temp=temp/10;
		}
		if(n==arm)
		System.out.print(n+" is armstrong number");
		else
		System.out.println(n+" is not armstrong number");
	}
}